#include "Geometry.h"
namespace mxr
{
	Geometry::Geometry()
	{
	}

	Geometry::~Geometry()
	{
	}

}