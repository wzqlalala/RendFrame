#include "Geode.h"
#include "NodeVisitor.h"
mxr::Geode::Geode()
{
}

mxr::Geode::~Geode()
{

}
