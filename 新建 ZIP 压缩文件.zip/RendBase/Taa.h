#pragma once
#include "qmatrix4x4.h"
#include "asset/fbo.h"

namespace mxr
{
	class MXR_EXPORT Taa
	{
	private:
		asset_ref<FBO> _fbo;






	public:




	};

}