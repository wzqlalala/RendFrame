#include "Renderer.h"

namespace mxr
{
	Renderer::Renderer()
	{
	}

	void Renderer::accept(NodeVisitor * visitor)
	{




	}

}