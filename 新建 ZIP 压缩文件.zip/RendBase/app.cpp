#include "app.h"


namespace mxr
{
	//Application& Application::GetInstance()
	//{
	//	// since C++11, this will be thread-safe, there's no need for manual locking
	//	static Application instance;
	//	return instance;

	//}
}

	


